package com.example.ichack_backend_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
